public class RandomQueueadsad<AnyType> {
	private int currentSize = 0;
	private ListNode front;
	private ListNode back;

	public RandomQueueadsad() {
		currentSize = 0;
		back = new ListNode(null);
		front = new ListNode(null, back);
	}	

	//	public void makeEmpty(){
	//		currentSize = 0;
	//		back = header;
	//		front.next = back;
	//		//front.next = back;
	//	}

	public boolean isEmpty() {
		return currentSize == 0;
	}

	public void enqueue(Object o) {
		if(isEmpty()) {
			back = new ListNode(o);
		}
		else if(currentSize == 1) {
			ListNode temp = new ListNode(o, front);
			back.next = temp;
		}
		else {
			ListNode temporar = back;
			temporar = back.next;
			back = new ListNode(o, temporar);
		}
		currentSize++;
	}

	public Object dequeue() {
		if(isEmpty()) {
			throw new UnderflowException( "Queue is empty" );
		}

		ListNode temp = back;
		int r = (int)(Math.random()*currentSize-1) + 1;
		for(int i = 0; i < r; i++) {
			temp = temp.next;
		}
		temp = temp.next;

		currentSize--;
		return temp.element;
	}

	public void print() {
		ListNode temp = front;
		while(temp.next != null) {
			temp = temp.next;
			if(temp.element == null) {
			}
			else {
				System.out.println(temp.element);
			}
		}
	}

	public String toString() {
		ListNode temp = back;
		String string = "[ ";
		while(temp.next.element != null) {
			string = string + ", " + temp.element;
			temp = temp.next;
		}
		return string + temp.element +" ]";
	}

	public static void main(String[] args) {
		RandomQueueadsad<Integer> test = new RandomQueueadsad<Integer>();

		test.enqueue(1);
		test.enqueue(2);
		test.enqueue(3);
		test.enqueue(4);
		
	}

}
