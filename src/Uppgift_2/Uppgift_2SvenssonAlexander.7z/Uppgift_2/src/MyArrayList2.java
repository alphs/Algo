import java.util.*;

public class MyArrayList<AnyType> implements Iterable<AnyType> {
	private AnyType[] list;
	private int count;

 
	public MyArrayList(){
	  list = (AnyType[]) new Object[10];
	  count=0;
	}
	
	
	public MyArrayList(int initialCapacity){
	 list = (AnyType[]) new Object[initialCapacity];
	}
	
	/*Appends the specified element to the end of this list.*/
	
	public boolean add(AnyType o){
		if(count >= list.length) {
			AnyType[] a = list.clone();
			System.arraycopy(a, 0, list = new AnyType[a.length*2], 0, a.length);
		}
		list[count] = o; 
		count++;
			return true;
	}
	
	
	/** tests if the specified element is a component of this list*/
	public boolean contains(AnyType o){
		for(int i = 0; i < list.length; i++) {
			if(list[i].equals(o)) {
				return true;
			}
		}
		return false;
	
	}
	/** returns the component at the specified index*/
	public AnyType get(int index){
		if(index < friends.length) {
			return friends[index];
			}
			else {
				return null;
			}
	}
	
	
	/** Search for the first occurrence of the given argument testing for the equality using
	equals method*/
	public int indexOf(AnyType o){
		if(list != null) {
			for(int i = 0; i < list.length; i++) {
				if(list[i].equals(o)) {
					return i;
				}
			}
			return -1;
		}
	}
	
	
	/** tests if this list has no components*/
	public boolean isEmpty(){
		if(list == null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	
	/** removes the first occurrence of the specified element in this list
	if the list contains the */
	public boolean remove(AnyType o){
		for(int i = 0; i < counter; i++) {
			if( friends[i].equals(name)) {
				for(int k  = i; k < friends.length-1; k++) {
					friends[k] = friends[k+1];
				}
				return true;
			}
		}
		return false;		
	}
	
	
	/** returns the number of components in this list*/
	public int size(){
		if(list == null) {
			return -1;
		}
		else {
			return list.length;
		}
	}
	
	
	/** returns an array containing all elements in this list in the correct order*/
	public Object [] toArray(){
		if(list == null) {
			return null
		}
		return list;
	}
	
	
	/** return object ArayListIterator */
	public Iterator<AnyType> iterator(){
		ArrayListIterator itr = new ArrayListIterator(list, list.length);
		return null;
	}

	
}